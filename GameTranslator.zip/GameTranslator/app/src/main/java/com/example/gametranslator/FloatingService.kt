package com.example.gametranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

class FloatingService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var root: View          // الزر العائم
    private lateinit var statusView: TextView
    private lateinit var overlay: OverlayView // الترجمة فوق النص
    private lateinit var btnParams: WindowManager.LayoutParams

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var capW = 0
    private var capH = 0

    @Volatile private var wantCapture = false
    private var auto = false
    private var busy = false
    private var cycleId = 0
    private var lastSig = ""
    private var modelReady = false

    private lateinit var recognizer: TextRecognizer
    private lateinit var translator: Translator
    private var srcLang = "en"
    private var intervalMs = 2500L
    private val cache = HashMap<String, String>() // ذاكرة الترجمات: النص المتكرر يظهر فوراً

    private val hideStatus = Runnable { statusView.visibility = View.GONE }

    // كل 2.5 ثانية: التقاط ثم ترجمة إذا تغيّر النص
    private val loop = object : Runnable {
        override fun run() {
            if (!auto) return
            if (!busy) startCycle()
            handler.postDelayed(this, intervalMs)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        srcLang = prefs.getString("lang", "en") ?: "en"
        intervalMs = prefs.getLong("interval", 2500L)
        recognizer = Langs.recognizer(srcLang)
        translator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(srcLang)
                .setTargetLanguage(TranslateLanguage.ARABIC)
                .build()
        )

        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        setupCapture()
        showViews()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("tr", "Translator", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "tr")
            .setContentTitle("مترجم الشاشة يعمل")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val p = Point()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealSize(p)
            p.x to p.y
        }

    // ---------- التقاط الشاشة ----------
    private fun newReader(w: Int, h: Int): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (!wantCapture) { img.close(); return@setOnImageAvailableListener }
            wantCapture = false
            val rw = rd.width
            val rh = rd.height
            val plane = img.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * rw
            val full = Bitmap.createBitmap(
                rw + rowPadding / plane.pixelStride, rh, Bitmap.Config.ARGB_8888
            )
            full.copyPixelsFromBuffer(plane.buffer)
            img.close()
            val bmp = Bitmap.createBitmap(full, 0, 0, rw, rh).copy(Bitmap.Config.ARGB_8888, true)
            // نطمس مكان الزر العائم كي لا يُقرأ
            val loc = IntArray(2)
            root.getLocationOnScreen(loc)
            Canvas(bmp).drawRect(
                loc[0].toFloat(), loc[1].toFloat(),
                (loc[0] + root.width).toFloat(), (loc[1] + root.height).toFloat(),
                Paint().apply { color = Color.BLACK }
            )
            handler.post {
                overlay.visibility = View.VISIBLE // نعيد إظهار الترجمة فوراً
                process(bmp)
            }
        }, handler)
        return r
    }

    private fun setupCapture() {
        val (w, h) = screenSize()
        capW = w; capH = h
        val r = newReader(w, h)
        reader = r
        display = projection?.createVirtualDisplay(
            "cap", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
        )
    }

    // عند تدوير الشاشة (ألعاب أفقية)
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        handler.postDelayed({
            val (w, h) = screenSize()
            if (w != capW || h != capH) {
                val old = reader
                val r = newReader(w, h)
                display?.resize(w, h, resources.displayMetrics.densityDpi)
                display?.surface = r.surface
                reader = r; capW = w; capH = h
                old?.close()
                overlay.items = emptyList()
                lastSig = ""
            }
        }, 300)
    }

    // ---------- الواجهة ----------
    private fun showViews() {
        // 1) طبقة الترجمة بملء الشاشة (لا تلتقط اللمس)
        overlay = OverlayView(this)
        val op = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 30) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        wm.addView(overlay, op)

        // 2) الزر العائم (فوق طبقة الترجمة)
        root = LayoutInflater.from(this).inflate(R.layout.floating_view, null)
        statusView = root.findViewById(R.id.tv_translation_result)
        val btn = root.findViewById<ImageView>(R.id.btn_floating_translate)
        btnParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 300 }

        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        btn.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = btnParams.x; startY = btnParams.y
                    touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    btnParams.x = startX + (e.rawX - touchX).toInt()
                    btnParams.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(root, btnParams)
                }
                MotionEvent.ACTION_UP -> {
                    if (abs(e.rawX - touchX) < 15 && abs(e.rawY - touchY) < 15) toggleAuto()
                }
            }
            true
        }
        wm.addView(root, btnParams)
    }

    private fun showStatus(msg: String) {
        statusView.text = msg
        statusView.visibility = View.VISIBLE
        handler.removeCallbacks(hideStatus)
        handler.postDelayed(hideStatus, 2500)
    }

    // ---------- التشغيل والإيقاف ----------
    private fun toggleAuto() {
        auto = !auto
        val btn = root.findViewById<ImageView>(R.id.btn_floating_translate)
        if (auto) {
            lastSig = ""
            btn.setColorFilter(Color.GREEN)
            showStatus("الترجمة التلقائية: تعمل")
            handler.post(loop)
        } else {
            handler.removeCallbacks(loop)
            cycleId++
            wantCapture = false
            busy = false
            overlay.items = emptyList()
            overlay.visibility = View.VISIBLE
            btn.clearColorFilter()
            showStatus("تم الإيقاف")
        }
    }

    private fun startCycle() {
        busy = true
        val id = ++cycleId
        overlay.visibility = View.INVISIBLE // نخفي الترجمة لحظياً لنرى النص الأصلي
        handler.postDelayed({ if (id == cycleId) wantCapture = true }, 100)
        handler.postDelayed({
            if (id == cycleId && wantCapture) { // لم يصل إطار جديد
                wantCapture = false
                busy = false
                overlay.visibility = View.VISIBLE
            }
        }, 1800)
    }

    // ---------- القراءة والترجمة ----------
    private fun process(bmp: Bitmap) {
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { res ->
                val blocks = res.textBlocks
                    .filter { b -> b.boundingBox != null && b.text.any { it.isLetter() } }
                    .take(25)
                if (blocks.isEmpty()) {
                    overlay.items = emptyList(); lastSig = ""; busy = false
                    return@addOnSuccessListener
                }
                val sig = blocks.joinToString("|") { it.text }
                if (sig == lastSig) { busy = false; return@addOnSuccessListener }
                lastSig = sig
                overlay.items = emptyList() // النص تغيّر، نمسح الترجمة القديمة
                ensureModel { translateBlocks(blocks) }
            }
            .addOnFailureListener { busy = false }
    }

    private fun ensureModel(onReady: () -> Unit) {
        if (modelReady) { onReady(); return }
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { modelReady = true; onReady() }
            .addOnFailureListener {
                showStatus("تعذّر تنزيل نموذج الترجمة، تأكد من الإنترنت")
                lastSig = ""; busy = false
            }
    }

    private fun translateBlocks(blocks: List<Text.TextBlock>) {
        if (cache.size > 500) cache.clear()
        val sep = if (srcLang == "ja" || srcLang == "zh" || srcLang == "ko") "" else " "
        val texts = blocks.map { it.text.replace("\n", sep) }
        val pending = texts.filter { !cache.containsKey(it) }.distinct()
        if (pending.isEmpty()) { finish(blocks, texts); return }
        var left = pending.size
        pending.forEach { t ->
            translator.translate(t).addOnCompleteListener { r ->
                if (r.isSuccessful) cache[t] = r.result
                left--
                if (left == 0) finish(blocks, texts)
            }
        }
    }

    private fun finish(blocks: List<Text.TextBlock>, texts: List<String>) {
        val items = blocks.indices.mapNotNull { k ->
            val tx = cache[texts[k]]
            val r = blocks[k].boundingBox
            if (tx != null && r != null) OverlayView.Item(Rect(r).apply { inset(-6, -3) }, tx)
            else null
        }.sortedBy { it.rect.top }
        // نتجاهل الخانات المتداخلة بشدة كي لا تتراكم الترجمات فوق بعضها
        val kept = ArrayList<OverlayView.Item>()
        for (item in items) {
            val overlaps = kept.any { o ->
                val x = Rect()
                x.setIntersect(o.rect, item.rect) &&
                    x.width().toLong() * x.height() >
                    0.5 * minOf(
                        o.rect.width().toLong() * o.rect.height(),
                        item.rect.width().toLong() * item.rect.height()
                    )
            }
            if (!overlaps) kept.add(item)
        }
        overlay.items = kept
        busy = false
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (::root.isInitialized) wm.removeView(root)
        if (::overlay.isInitialized) wm.removeView(overlay)
        display?.release()
        reader?.close()
        projection?.stop()
        if (::recognizer.isInitialized) recognizer.close()
        if (::translator.isInitialized) translator.close()
        super.onDestroy()
    }
}
