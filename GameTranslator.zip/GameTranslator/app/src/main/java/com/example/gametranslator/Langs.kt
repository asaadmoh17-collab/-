package com.example.gametranslator

import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

object Langs {
    // (الاسم المعروض، رمز اللغة)
    val list = listOf(
        "الإنجليزية" to "en", "الإسبانية" to "es", "الفرنسية" to "fr",
        "الألمانية" to "de", "الإيطالية" to "it", "البرتغالية" to "pt",
        "التركية" to "tr", "الإندونيسية" to "id",
        "اليابانية" to "ja", "الصينية" to "zh", "الكورية" to "ko"
    )

    fun recognizer(code: String): TextRecognizer = when (code) {
        "ja" -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        "zh" -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        "ko" -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }
}
