package com.example.gametranslator

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val speeds = listOf(
        "سريع (1.5 ثانية)" to 1500L,
        "عادي (2.5 ثانية)" to 2500L,
        "موفّر للبطارية (5 ثوانٍ)" to 5000L
    )

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, FloatingService::class.java)
                    .putExtra("code", r.resultCode)
                    .putExtra("data", data)
                ContextCompat.startForegroundService(this, i)
                finish() // ارجع للعبة وستجد الزر العائم
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val langSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                Langs.list.map { it.first }
            )
            val cur = prefs.getString("lang", "en")
            setSelection(Langs.list.indexOfFirst { it.second == cur }.coerceAtLeast(0))
        }
        val speedSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                speeds.map { it.first }
            )
            val cur = prefs.getLong("interval", 2500L)
            setSelection(speeds.indexOfFirst { it.second == cur }.coerceAtLeast(0))
        }
        val btn = Button(this).apply { text = "تشغيل الترجمة العائمة" }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 48, 48, 48)
            addView(TextView(context).apply { text = "لغة اللعبة (المصدر):" })
            addView(langSpinner)
            addView(TextView(context).apply { text = "سرعة الترجمة:"; setPadding(0, 32, 0, 0) })
            addView(speedSpinner)
            addView(btn)
        })

        btn.setOnClickListener {
            prefs.edit()
                .putString("lang", Langs.list[langSpinner.selectedItemPosition].second)
                .putLong("interval", speeds[speedSpinner.selectedItemPosition].second)
                .apply()

            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
                return@setOnClickListener
            }
            if (Build.VERSION.SDK_INT >= 33) {
                ActivityCompat.requestPermissions(
                    this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1
                )
            }
            val mpm = getSystemService(MediaProjectionManager::class.java)
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        }
    }
}
