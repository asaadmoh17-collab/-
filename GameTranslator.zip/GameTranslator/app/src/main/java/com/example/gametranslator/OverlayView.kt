package com.example.gametranslator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.View
import kotlin.math.max
import kotlin.math.min

/** طبقة بملء الشاشة ترسم الترجمة فوق مكان النص الأصلي مباشرة */
class OverlayView(ctx: Context) : View(ctx) {

    data class Item(val rect: Rect, val text: String)

    var items: List<Item> = emptyList()
        set(value) { field = value; invalidate() }

    private val density = resources.displayMetrics.density
    private val bg = Paint().apply { color = 0xE6101010.toInt() }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

    override fun onDraw(c: Canvas) {
        val pad = (3 * density).toInt()
        for (it in items) {
            val r = it.rect
            c.drawRect(r, bg)
            val width = max(r.width() - 2 * pad, 20)
            var size = min(r.height().toFloat(), 40f * density)
            var layout: StaticLayout
            while (true) {
                tp.textSize = size
                layout = StaticLayout.Builder.obtain(it.text, 0, it.text.length, tp, width)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .build()
                if (layout.height <= r.height() - 2 * pad || size <= 9f * density) break
                size -= 2f
            }
            c.save()
            c.translate(
                r.left.toFloat() + pad,
                r.top + max(0f, (r.height() - layout.height) / 2f)
            )
            layout.draw(c)
            c.restore()
        }
    }
}
